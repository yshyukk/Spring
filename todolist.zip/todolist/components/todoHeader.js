let template = `<div id="myDIV" class="header">
    <h2>My To Do List</h2>
    <input type="text" id="myInput" v-model="title" placeholder="Title...">
    <span @click="newElement" class="addBtn">Add</span>
</div>`;

export default {
  template,
  data: function () {
    return {
      title: "",
    };
  },
  methods: {
    newElement: function () {
      const component = this;
      $.ajax({
        crossOrigin: true,
        url: "http://127.0.0.1:8090/todo/list",
        type: "post",
        dataType: 'json',
        data: {
          Id: 0,
          Contents: component.title,
        },
        success: function (data) {
          if (data != null) {
            alert("등록");
            component.title = "";
            component.$router.go(0);
          }
        },
        error: function (reject) {
          console.log(reject);
        },
      });
    },
  },
};
