let template = `
<div>
    <ul id="myUL"> 
        <template v-for="item in items">
            <li :key="item.no" :class="{checked : item.todoyn == '1'}" @click="checkItem(item)">
                {{item.contents}}
                <span class="close" @click.self.stop="deleteItem(item.no)">x</span>
            </li>
        </template>
    </ul>
</div>
`;

export default {
  template,
  data: function () {
    return {
      items: [], // 서버에서 가져오는 원본 데이터
      updateItem: {},
    };
  },
  created: function () {
    this.loadData();
  },
  watch: {
    updateItem: function () {
      const component = this;
      console.log(this.updateItem.no);
      console.log(this.updateItem.todoyn);
      $.ajax({
        url: "http://127.0.0.1:8090/todo/list",
        type: "put",
        dataType: "json",
        contentType : "application/json; charset=utf-8",
        data: JSON.stringify(component.updateItem),
        success: function (data) {
          if (data != null) {
            alert("수정");
          }
        },
        error: function (reject) {
          console.log(reject);
        },
      });
    },
  },
  methods: {
    loadData: function () {
      const component = this;
      $.ajax({
        url: "http://127.0.0.1:8090/todo/list",
        type: "get",
        data: { id: 0 },
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
          if (data != null) {
            console.log(data);
            component.items = data;
          }
        },
        error: function (reject) {
          console.log(reject);
        },
      });
    },
    checkItem: function (item) {
      item.todoyn = item.todoyn == "1" ? "0" : "1";
      this.updateItem = { ...item };
    },
    deleteItem: function (no) {
      const component = this;
      $.ajax({
        url: "http://127.0.0.1:8090/todo/list/" + no,
        type: "delete",
        dataType: "json",
        contentType: "application/json",
        success: function (data) {
          if (data != null) {
            alert("삭제");
            component.items = $.grep(component.items, function (list) {
              return !(list.no == no);
            });
          }
        },
        error: function (reject) {
          console.log(reject);
        },
      });
    },
  },
};
